package com.example.acitivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MENOS extends AppCompatActivity {

    private EditText desde03;
    private EditText desde04;
    private TextView resultado1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menos);

        desde03 = findViewById(R.id.desde03);
        desde04 = findViewById(R.id.desde04);
        resultado1 = findViewById(R.id.resultado2);

        Button b = (Button) findViewById(R.id.btn_returnar2);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MENOS.this,MainActivity.class);
                startActivity(it);
            }
        });
    }

    public void btn_calcular(View view)
    {
        float valor1 = Integer.parseInt(desde03.getText().toString());
        float valor2 = Integer.parseInt(desde04.getText().toString());
        resultado1.setText(String.valueOf(valor1 - valor2));
    }
    }