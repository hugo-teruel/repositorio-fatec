package com.example.acitivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SOMA extends AppCompatActivity {

    private EditText desde01;
    private EditText desde02;
    private TextView resultado1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.soma);

        desde01 = findViewById(R.id.desde01);
        desde02 = findViewById(R.id.desde02);
        resultado1 = findViewById(R.id.resultado1);

        Button b = (Button) findViewById(R.id.btn_returnar);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(SOMA.this,MainActivity.class);
                startActivity(it);
            }
        });
    }

    public void btn_somar(View view)
    {
        float valor1 = Integer.parseInt(desde01.getText().toString());
        float valor2 = Integer.parseInt(desde02.getText().toString());
        resultado1.setText(String.valueOf(valor1 + valor2));
    }
    }