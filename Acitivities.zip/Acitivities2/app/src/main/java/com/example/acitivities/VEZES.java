package com.example.acitivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class VEZES extends AppCompatActivity {

    private EditText desde05;
    private EditText desde06;
    private TextView resultado3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vezes);

        desde05 = findViewById(R.id.desde05);
        desde06 = findViewById(R.id.desde06);
        resultado3 = findViewById(R.id.resultado3);

        Button b = (Button) findViewById(R.id.btn_returnar3);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(VEZES.this,MainActivity.class);
                startActivity(it);
            }
        });
    }

    public void btn_vezes(View view)
    {
        float valor1 = Integer.parseInt(desde05.getText().toString());
        float valor2 = Integer.parseInt(desde06.getText().toString());
        resultado3.setText(String.valueOf(valor1 * valor2));
    }
}