package com.example.acitivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DIVIDIR extends AppCompatActivity {

    private EditText desde08;
    private EditText desde09;
    private TextView resultado4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dividir);

        desde08 = findViewById(R.id.desde08);
        desde09 = findViewById(R.id.desde09);
        resultado4 = findViewById(R.id.resultado4);

        Button b = (Button) findViewById(R.id.btn_returnar4);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(DIVIDIR.this,MainActivity.class);
                startActivity(it);
            }
        });
    }

    public void btn_vezes(View view)
    {
        float valor1 = Integer.parseInt(desde08.getText().toString());
        float valor2 = Integer.parseInt(desde09.getText().toString());
        resultado4.setText(String.valueOf(valor1 / valor2));
    }

}